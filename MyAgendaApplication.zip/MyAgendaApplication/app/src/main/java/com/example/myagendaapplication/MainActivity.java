package com.example.myagendaapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.Nullable;

import android.os.Bundle;
import android.content.Intent;
import android.view.View;
import android.widget.TextView;
import android.widget.EditText;
import android.widget.Button;
import android.widget.ListView;


public class MainActivity extends AppCompatActivity {

    TextView textViewList;
    Button buttonAdd;
    ListView

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("MainActivity");
        textViewList = findViewById(R.id.textViewList);
        buttonAdd = findViewById(R.id.buttonAdd);

    }

    @Override
    protected void onActivityResult (int requestCode, int resultCode, @Nullable Intent data) {

        super.onActivityResult(requestCode, resultCode, data);
        final int RESULT_TO_SECOND_ACTIVITY = 1001;
        if ( requestCode==RESULT_TO_SECOND_ACTIVITY){
            if(requestCode == RESULT_OK){
                String msgBack = data.getStringExtra("msgBack");
                textViewList.setText(msgBack);
            }
        }
    }

    public void buttonAddClicked (View view){
        Intent intent = new Intent( MainActivity.this, SecondActivity.class);
        String msg = textViewList.getText().toString();
        intent.putExtra("msg",msg);
        startActivityForResult(intent, RESULT_TO_SECOND_ACTIVITY);
    }
    @Override
    public void onBackPressed(){

    };

}