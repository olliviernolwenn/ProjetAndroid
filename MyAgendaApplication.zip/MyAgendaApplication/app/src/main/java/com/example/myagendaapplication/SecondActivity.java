package com.example.myagendaapplication;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;


public class SecondActivity extends AppCompatActivity {

    TextView textViewName;
    TextView textViewNameAdress;
    TextView textViewNamePhone;
    EditText editTextName;
    EditText editTextNameAdress;
    EditText editTextNamePhone;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        setTitle("ListApp");
        textViewName = findViewById(R.id.textViewName);
        textViewNameAdress = findViewById(R.id.textViewAdress);
        textViewNamePhone = findViewById(R.id.textViewPhone);
        editTextName =  findViewById(R.id.editTextName);
        editTextNameAdress =  findViewById(R.id.editTextNameAdress);
        editTextNamePhone =  findViewById(R.id.editTextNamePhone);

        Bundle extras = getIntent().getExtras();
        if (extras!= null){
            String msg = extras.getString("msg");
            textViewName.setText(msg);
        }
    }


    public void onBackPressed(){
        AlertDialog.Builder builder = new AlertDialog.Builder(SecondActivity.this);
        builder.setTitle(android.R.string.dialog_alert_title);
        builder.setMessage("Do you want to go back?");
        builder.setNegativeButton(android.R.string.no,null);
        builder.setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int i) {
                Intent intent = new Intent();
                String msgBack = editTextName.getText().toString();
                intent.putExtra("msgBack",msgBack);
                setResult(RESULT_OK,intent);
                finish();
            }
        });

        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }
}