package com.esigelec.myfirstapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Button;
import android.widget.Toast;
import com.example.mycalculatorapplication.R;

public class MainActivity extends AppCompatActivity {
    TextView textViewCalculator;
    TextView textViewNum1;
    TextView textViewNum2;
    TextView textViewResult;
    EditText editTextNameNum1;
    EditText editTextNameNum2;
    EditText editTextNameResult;
    Button buttonAdd;
    Button buttonSubstract;
    Button buttonMultiply;
    Button buttonDivide;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textViewCalculator = findViewById(R.id.textViewCalculator);
        textViewNum1 = findViewById(R.id.textViewNum1);
        textViewNum2 = findViewById(R.id.textViewNum2);
        textViewResult = findViewById(R.id.textViewResult);
        editTextNameNum1 = findViewById(R.id.editTextNameNum1);
        editTextNameNum2 = findViewById(R.id.editTextNameNum2);
        editTextNameResult = findViewById(R.id.editTextNameResult);
        buttonAdd = findViewById(R.id.buttonAdd);
        buttonSubstract = findViewById(R.id.buttonSubstract);
        buttonMultiply = findViewById(R.id.buttonMultiply);
        buttonDivide = findViewById(R.id.buttonDivide);

        textViewCalculator.setText("Hello Esigelec!");
        Log.d("MainActivity", "onCreate Called");
    }

    public void buttonAddClicked(View view) {
        Log.v("MainActivity", "buttonAddClicked");
        String name1 = editTextNameNum1.getText().toString();
        textViewNum1.setText(name1);
        String name2 = editTextNameNum2.getText().toString();
        textViewNum2.setText(name2);
        int add1 = Integer.parseInt(name1);
        int add2 = Integer.parseInt(name2);
        int result1 = add1 + add2;
        textViewResult.setText(result1);
    }

    public void buttonSubstractClicked(View view) {
        Log.v("MainActivity", "buttonSubstractClicked");
        String name3 = editTextNameNum1.getText().toString();
        textViewNum1.setText(name3);
        String name4 = editTextNameNum2.getText().toString();
        textViewNum2.setText(name4);
        int add3 = Integer.parseInt(name3);
        int add4 = Integer.parseInt(name4);
        int result2 = add3 - add4;
        textViewResult.setText(result2);
    }

    public void buttonMultiplyClicked(View view) {
        Log.v("MainActivity", "buttonDivideClicked");
        String name5 = editTextNameNum1.getText().toString();
        textViewNum1.setText(name5);
        String name6 = editTextNameNum2.getText().toString();
        textViewNum2.setText(name6);
        int add5 = Integer.parseInt(name5);
        int add6 = Integer.parseInt(name6);
        int result3 = add5 * add6;
        textViewResult.setText(result3);
    }
    buttonDivide.setOnClicked(new View.OnClickListener(){
        public void onClick(View v){
            Log.v("Main Activity", "buttonDivide");
            String name7 = editTextNameNum1.getText().toString();
            textViewNum1.setText(name7);
            String name8 = editTextNameNum2.getText().toString();
            textViewNum2.setText(name8);
            int add7 = Integer.parseInt(name7);
            int add8 = Integer.parseInt(name8);
            if (add8 ==0){
                Toast.makeText(getApplicationContext(),"Not allow to make a division by 0", Toast.LENGTH_LONG).show();
            }
            int result4 = add7 / add8;
            textViewResult.setText(result4);
        }
    })

    @Override
    protected void onStart() {
        super.onStart();
        Log.w("MainActivity","onStart Called");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.e("MainActivity","onResume Called");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.v("MainActivity","onPause Called");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.wtf("MainActivity","onStop Called");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.wtf("MainActivity","onDestroy Called");
    }
}